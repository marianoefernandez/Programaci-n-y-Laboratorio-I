float sumar(float x, float y); // Funci�n usada para sumar dos n�meros ,  se declaran flotantes por si el usuario desea sumar con numeros con coma, se ingresan los datos de las variables a y b y devuelve su suma a+b.
float restar(float x, float y); // Funci�n para restar dos n�meros , se declaran flotantes por si el usuario desea restar con numeros con coma, se ingresan los datos de las variables a y b y devuelve su resta a-b.
float dividir(float x, float y); // Funci�n para dividir dos n�meros , se declaran flotantes por si el resultado da numero con coma, se ingresan los datos de las variables a y b y devuelve su division a/b, en caso de division por 0 registra un mensaje de error.
float multiplicar(float x, float y); // Funci�n para multiplicar dos n�meros , se declaran flotantes por si el usuario desea multiplicar con numeros con coma, se ingresan los datos de las variables a y b y devuelve su multiplicaci�n a*b.
int factorialA(int x); // Funci�n para sacar el factorial de A , es entero porque el factorial es s�lo para enteros , se ingresa un n�mero A y devuelve el factorial !A , Factorial 0 da 1 porque conjunto vacio representa 1.
int factorialB(int y); // Funci�n para sacar el factorial de B , es entero porque el factorial es s�lo para enteros , se ingresa un n�mero B y devuelve el factorial !B , Factorial 0 da 1 porque conjunto vacio representa 1.

